"""Python Shared Core."""
