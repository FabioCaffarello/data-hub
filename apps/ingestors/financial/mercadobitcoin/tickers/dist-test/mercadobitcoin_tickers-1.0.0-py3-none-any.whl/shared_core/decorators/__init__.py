"""Shared decorators."""
