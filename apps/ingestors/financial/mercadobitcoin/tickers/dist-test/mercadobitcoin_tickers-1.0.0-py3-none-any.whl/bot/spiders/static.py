BASE_ENDPOINT = "https://www.mercadobitcoin.net/api"
PATH_ENDPOINT = "symbols"
