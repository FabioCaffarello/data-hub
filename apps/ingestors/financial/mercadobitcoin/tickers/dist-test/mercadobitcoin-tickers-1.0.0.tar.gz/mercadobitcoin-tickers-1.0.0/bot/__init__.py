"""mercadobitcoin tickers."""
