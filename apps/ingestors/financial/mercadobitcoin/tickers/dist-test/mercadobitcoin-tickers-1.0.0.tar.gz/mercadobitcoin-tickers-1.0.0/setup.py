# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['baseparser',
 'bot',
 'bot.spiders',
 'bot.spiders.proto',
 'bot.tests',
 'bot.tests.bot',
 'ingestor',
 'ingestor.spiders',
 'ingestor.tests',
 'shared_core',
 'shared_core.decorators']

package_data = \
{'': ['*'], 'bot.tests': ['debug/*', 'debug/response/*', 'reference_files/*']}

extras_require = \
{':python_version >= "3.8" and python_version < "3.10"': ['attrs==22.2.0',
                                                          'automat==22.10.0',
                                                          'beanie==1.17.0',
                                                          'certifi==2022.12.7',
                                                          'cffi==1.15.1',
                                                          'charset-normalizer==3.0.1',
                                                          'click==8.1.3',
                                                          'constantly==15.1.0',
                                                          'cryptography==39.0.0',
                                                          'cssselect==1.2.0',
                                                          'dnspython==2.3.0',
                                                          'filelock==3.9.0',
                                                          'hyperlink==21.0.0',
                                                          'idna==3.4',
                                                          'incremental==22.10.0',
                                                          'itemadapter==0.7.0',
                                                          'itemloaders==1.0.6',
                                                          'jmespath==1.0.1',
                                                          'lazy-model==0.0.5',
                                                          'lxml==4.9.2',
                                                          'motor==3.1.1',
                                                          'packaging==23.0',
                                                          'parsel==1.7.0',
                                                          'protego==0.2.1',
                                                          'protobuf==4.21.12',
                                                          'pyasn1-modules==0.2.8',
                                                          'pyasn1==0.4.8',
                                                          'pycparser==2.21',
                                                          'pydantic==1.10.4',
                                                          'pymongo==4.3.3',
                                                          'pyopenssl==23.0.0',
                                                          'python-json-logger==2.0.4',
                                                          'queuelib==1.6.2',
                                                          'requests-file==1.5.1',
                                                          'requests==2.28.2',
                                                          'scrapy==2.8.0',
                                                          'service-identity==21.1.0',
                                                          'setuptools==67.1.0',
                                                          'six==1.16.0',
                                                          'tldextract==3.4.0',
                                                          'toml==0.10.2',
                                                          'twisted==22.10.0',
                                                          'typing-extensions==4.4.0',
                                                          'urllib3==1.26.14',
                                                          'w3lib==2.1.1',
                                                          'zope-interface==5.5.2'],
 ':python_version >= "3.8" and python_version < "3.10" and platform_python_implementation == "CPython"': ['pydispatcher==2.0.6'],
 ':python_version >= "3.8" and python_version < "3.10" and platform_python_implementation == "PyPy"': ['pypydispatcher==2.1.2'],
 ':python_version >= "3.8" and python_version < "3.10" and platform_system == "Windows"': ['colorama==0.4.6',
                                                                                           'twisted-iocpsupport==1.0.2']}

setup_kwargs = {
    'name': 'mercadobitcoin-tickers',
    'version': '1.0.0',
    'description': 'mercadobitcoin tickers.',
    'long_description': '# ingestors-financial-mercadobitcoin-tickers\n\n## About\n\nProject description here.\n\n[API Documentation]()\n\n## [Change log](CHANGELOG.md)\n',
    'author': 'FabioCaffarello',
    'author_email': 'fabio.caffarello@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'extras_require': extras_require,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
